from flask import Blueprint

account = Blueprint('account', __name__)
