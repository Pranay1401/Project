from flask import Blueprint

quiz = Blueprint('quiz', __name__)
